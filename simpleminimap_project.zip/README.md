# Simple Minimap v1.5.0

Клиентская миникарта для Forge 26.3 (Minecraft 26.3, Java 25).
Серверу мод не нужен и не виден.

## Сборка через GitHub (без компьютера)

1. Создай репозиторий на github.com (New repository, Public).
2. Add file -> Upload files -> выбери ОДИН файл: этот архив (simpleminimap_project.zip). Не распаковывай!
3. Commit changes.
4. Add file -> Create new file. Имя файла: .github/workflows/build.yml
   Вставь содержимое workflow (см. ниже) и Commit.
5. Вкладка Actions: дождись зелёной галочки (10-15 мин).
6. Открой сборку, внизу раздел Artifacts -> скачай simpleminimap.
7. Внутри архива лежит jar -> кинь его в папку mods профиля (на планшете:
   Android/data/<лаунчер>/files/.minecraft/mods/).

### Содержимое build.yml

```yaml
name: Build mod
on:
  push:
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Unpack sources
        run: |
          unzip -o -q simpleminimap_project.zip -d unpack
          cp -r unpack/. .
      - name: Set up JDK 25
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '25'
      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4
      - name: Build
        run: gradle build --no-daemon
      - name: Upload jar
        uses: actions/upload-artifact@v4
        with:
          name: simpleminimap
          path: build/libs/*.jar
```

## Сборка на ПК (альтернатива)

1. Скачай Forge MDK 26.3 (files.minecraftforge.net, кнопка Mdk).
2. Скопируй папку src из архива поверх MDK (с заменой).
3. Установи JDK 25 (Temurin). Открой папку в IntelliJ IDEA, дождись Gradle.
4. Gradle -> Tasks -> build -> build. Jar будет в build/libs.

## Управление

| Действие | Клавиша по умолчанию |
|---|---|
| Карта вкл/выкл | M |
| Худ настроек | O |
| Метка на месте игрока | B |
| Зона: начать | Shift+Z |
| Зона: точка 1 | 1 |
| Зона: точка 2 | 2 |

Свои комбинации (до 3 клавиш) настраиваются в худе настроек (O).
ЛКМ, ПКМ, Enter и Пробел зарезервированы и не записываются.

## Возможности

- Квадратная миникарта, сетка чанков, рельеф с затенением, цвета биомов.
- Точки: игроки (голубые), монстры (красные), животные (оранжевые), прочие (серые).
- Стрелка направления взгляда (карта ориентирована севером вверх).
- Метки: имя, координаты, цвет, скрытие (призрак 25%), редактор, папки.
- Зоны: две точки, цвет обводки/заливки/на карте, подпись в мире с размером X:Z.
- Худ времени: значок солнца/луны + отсчёт до ночи/рассвета.
- Кэш чанков: сканирование один раз + периодическое обновление (экономия FPS).

## Настройки (в коде: MinimapRenderer/Settings, и в худе O)

| Параметр | Значение для Huawei MatePad 11.5S |
|---|---|
| RADIUS | 64 |
| SCALE | 0.75 |
| REPAINT_MS | 150 |
| SCAN_PER_TICK | 24 |
| RESCAN_MS | 5000 |

Если FPS проседает: SCAN_PER_TICK -> 12, REPAINT_MS -> 200, RADIUS -> 48.
Если запас есть: SCAN_PER_TICK -> 40, RADIUS -> 80.

## Sodium (рекомендуемые настройки для планшета)

Дистанция прорисовки 8, симуляция 6, графика Быстрая, сглаженное освещение
Минимальное, частицы минимальные, облака и тени сущностей выкл, лимит FPS 60,
Sodium Extra: анимации воды/огня/частиц выкл.

## Примечание

Код написан под Forge 26.x; точные имена классов/методов могут отличаться
от финальных маппингов. Если Gradle выдаст ошибку компиляции — пришли текст
ошибки, поправим точечно.
