package ru.example.simpleminimap;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiLayersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SimpleMinimap.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class HudOverlay {
    public static boolean visible = true;

    @SubscribeEvent
    public static void onRegister(RegisterGuiLayersEvent e) {
        e.registerAboveAll("simpleminimap_hud", HudOverlay::render);
    }

    private static void render(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        MinimapRenderer.mapOnScreen = false;
        if (visible) MinimapRenderer.render(g, mc);
        renderTimeHud(g, mc);
    }

    private static void renderTimeHud(GuiGraphics g, Minecraft mc) {
        if (mc.level == null) return;
        long t = mc.level.getDayTime() % 24000L;
        boolean day = t < 13000L;
        long remain = day ? 13000L - t : 24000L - t;
        long totalSec = remain * 50L / 1000L;
        long mm = totalSec / 60, ss = totalSec % 60;
        String text = (day ? "До ночи: " : "До рассвета: ") + mm + ":"
                + (ss < 10 ? "0" : "") + ss;

        int w = g.guiWidth();
        int y;
        if (visible && MinimapRenderer.mapOnScreen) {
            int size = (int) (Settings.radius * 2 * Settings.scale);
            y = 6 + size + 20;
        } else {
            y = 6;
        }

        int icon = day ? 0xFFFFDD55 : 0xFFCCE0FF;
        g.fill(w - 116, y, w - 104, y + 12, icon);
        g.renderOutline(w - 116, y, w - 104, y + 12, 0xFF000000);
        g.drawString(mc.font, text, w - 100, y + 2, 0xFFFFFF);
    }
}
