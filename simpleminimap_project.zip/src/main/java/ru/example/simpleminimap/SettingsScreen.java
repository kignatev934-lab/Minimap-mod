package ru.example.simpleminimap;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class SettingsScreen extends Screen {
    private final Screen parent;

    private static final int[] RADII = {32, 48, 64, 80, 96};
    private static final int[] SCALES = {50, 60, 75, 90, 100};
    private static final int[] REPAINTS = {100, 150, 200, 250};
    private static final int[] SCANS = {12, 24, 40};
    private static final int[] RESCANS = {3000, 5000, 10000};

    private static final String[] ACTION_NAMES = {
            "Карта", "Настройки", "Метка", "Зона (Shift+)", "Зона: точка 1", "Зона: точка 2"
    };
    private static final KeyCombo[] COMBOS = {
            Settings.TOGGLE_MAP, Settings.OPEN_SETTINGS, Settings.QUICK_WAYPOINT,
            Settings.ZONE_START, Settings.ZONE_P1, Settings.ZONE_P2
    };

    private int recordingAction = -1;
    private List<Integer> recorded = new ArrayList<>();
    private String error = "";

    public SettingsScreen(Screen parent) {
        super(Component.literal("Simple Minimap - настройки"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int w = this.width;
        int y = 34;
        cycle(w / 2 - 120, y, 115, "Радиус", RADII, Settings.radius, v -> Settings.radius = v);
        cycle(w / 2 + 5, y, 115, "Масштаб", SCALES, (int) (Settings.scale * 100),
                v -> Settings.scale = v / 100f);
        y += 26;
        cycle(w / 2 - 120, y, 115, "Обновление мс", REPAINTS, Settings.repaintMs, v -> Settings.repaintMs = v);
        cycle(w / 2 + 5, y, 115, "Скан за тик", SCANS, Settings.scanPerTick, v -> Settings.scanPerTick = v);
        y += 26;
        cycle(w / 2 - 120, y, 115, "Перескан мс", RESCANS, Settings.rescanMs, v -> Settings.rescanMs = v);
        addRenderableWidget(Button.builder(
                Component.literal("Цвет зон: #" + Integer.toHexString(Settings.PALETTE[Settings.zoneDefaultColor] & 0xFFFFFF)),
                b -> {
                    Settings.zoneDefaultColor = (Settings.zoneDefaultColor + 1) % Settings.PALETTE.length;
                    b.setMessage(Component.literal("Цвет зон: #"
                            + Integer.toHexString(Settings.PALETTE[Settings.zoneDefaultColor] & 0xFFFFFF)));
                    Settings.save();
                }).bounds(w / 2 + 5, y, 115, 20).build());
        y += 34;

        for (int i = 0; i < COMBOS.length; i++) {
            final int idx = i;
            String label = (recordingAction == idx ? "запись... (" : ACTION_NAMES[i] + ": ")
                    + (recordingAction == idx ? recorded.size() + "/3" : COMBOS[i].label);
            addRenderableWidget(Button.builder(Component.literal(label), b -> {
                if (recordingAction == idx) {
                    commitCombo(idx);
                } else {
                    recordingAction = idx;
                    recorded = new ArrayList<>();
                    error = "";
                }
                rebuild();
            }).bounds(w / 2 - 120, y, 190, 20).build());
            y += 24;
        }
        y += 4;

        addRenderableWidget(Button.builder(Component.literal("Метки"), b ->
                        this.minecraft.setScreen(new WaypointsScreen()))
                .bounds(w / 2 - 120, y, 115, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Клавиши Minecraft"), b ->
                        this.minecraft.setScreen(new net.minecraft.client.gui.screens.options.controls.KeyBindsScreen(
                                this, this.minecraft.options)))
                .bounds(w / 2 + 5, y, 115, 20).build());
        y += 26;
        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose())
                .bounds(w / 2 - 60, y, 120, 20).build());
    }

    private int findIdx(int[] vals, int cur) {
        for (int i = 0; i < vals.length; i++) if (vals[i] == cur) return i;
        return 0;
    }

    private void cycle(int x, int yy, int ww, String name, int[] vals, int cur, Consumer<Integer> setter) {
        final int[] idx = {findIdx(vals, cur)};
        Button b = Button.builder(Component.literal(name + ": " + vals[idx[0]]), btn -> {
            idx[0] = (idx[0] + 1) % vals.length;
            setter.accept(vals[idx[0]]);
            btn.setMessage(Component.literal(name + ": " + vals[idx[0]]));
            Settings.save();
        }).bounds(x, yy, ww, 20).build();
        addRenderableWidget(b);
    }

    private void commitCombo(int idx) {
        int[] arr = new int[recorded.size()];
        StringBuilder label = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            arr[i] = recorded.get(i);
            if (i > 0) label.append('+');
            label.append(KeyCombo.keyName(arr[i]));
        }
        COMBOS[idx].set(arr, label.length() == 0 ? "-" : label.toString());
        recordingAction = -1;
        error = "";
        Settings.save();
    }

    private void rebuild() {
        clearWidgets();
        init();
    }

    @Override
    public boolean keyPressed(int code, int scan, int mods) {
        if (recordingAction >= 0) {
            if (code == GLFW.GLFW_KEY_ESCAPE) {
                recordingAction = -1;
                error = "";
                rebuild();
                return true;
            }
            if (code == GLFW.GLFW_KEY_ENTER || code == GLFW.GLFW_KEY_KP_ENTER || code == GLFW.GLFW_KEY_SPACE) {
                error = "Enter и Пробел использовать нельзя";
                return true;
            }
            if (recorded.size() < 3) {
                recorded.add(code);
                if (recorded.size() == 3) {
                    commitCombo(recordingAction);
                }
                rebuild();
            }
            return true;
        }
        return super.keyPressed(code, scan, mods);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (recordingAction >= 0) {
            if (btn == 0 || btn == 1) {
                error = "ЛКМ и ПКМ использовать нельзя";
            }
            return true;
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public void onClose() {
        Settings.save();
        this.minecraft.setScreen(parent);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g, mouseX, mouseY, partial);
        g.drawCenteredString(this.font, this.title, this.width / 2, 14, 0xFFFFFF);

        int y = 34 + 84;
        for (int i = 0; i < COMBOS.length; i++) {
            String hint = recordingAction == i
                    ? "жми до 3 клавиш, Esc - отмена"
                    : "клавиша = перезапись";
            g.drawString(this.font, hint, this.width / 2 + 75, y + 6, 0xFF909090);
            y += 24;
        }

        int sw = this.width / 2 + 5;
        for (int i = 0; i < Settings.PALETTE.length; i++) {
            int px = sw + i * 14;
            g.fill(px, 34 + 52, px + 12, 34 + 64, Settings.PALETTE[i]);
            if (i == Settings.zoneDefaultColor) {
                g.renderOutline(px - 1, 34 + 51, px + 13, 34 + 65, 0xFFFFFFFF);
            }
        }

        if (!error.isEmpty()) {
            g.drawCenteredString(this.font, error, this.width / 2, this.height - 14, 0xFFFF5555);
        }
        super.render(g, mouseX, mouseY, partial);
    }
}
