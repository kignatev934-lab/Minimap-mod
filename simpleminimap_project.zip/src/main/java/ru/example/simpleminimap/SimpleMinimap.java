package ru.example.simpleminimap;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.common.Mod;

@Mod(value = SimpleMinimap.MODID, dist = Dist.CLIENT)
public class SimpleMinimap {
    public static final String MODID = "simpleminimap";

    public SimpleMinimap() {
        Settings.load();
        MinimapData.get();
    }
}
