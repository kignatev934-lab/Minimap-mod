package ru.example.simpleminimap;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class WaypointsScreen extends Screen {
    private int scroll = 0;
    private String currentFolder = "all";
    private int pendingDelete = -1;
    private EditBox folderBox;

    private static final int ROW_H = 26;
    private static final int ROWS = 6;

    public WaypointsScreen() {
        super(Component.literal("Simple Minimap - метки"));
    }

    @Override
    protected void init() {
        int w = this.width;
        addRenderableWidget(Button.builder(Component.literal(folderLabel()), b -> cycleFolder())
                .bounds(w / 2 - 150, 28, 120, 20).build());
        addRenderableWidget(Button.builder(Component.literal(folderVisible() ? "Скрыть папку" : "Вкл папку"), b -> {
            Folder f = MinimapData.findFolder(currentFolder);
            if (f != null) {
                f.visible = !f.visible;
                MinimapData.save();
            }
            rebuild();
        }).bounds(w / 2 - 24, 28, 90, 20).build());

        folderBox = new EditBox(this.font, w / 2 + 72, 28, 90, 20, Component.literal("папка"));
        folderBox.setMaxLength(24);
        addRenderableWidget(folderBox);
        addRenderableWidget(Button.builder(Component.literal("+ папка"), b -> {
            String n = folderBox.getValue().trim();
            if (!n.isEmpty() && MinimapData.findFolder(n) == null) {
                MinimapData.get().folders.add(new Folder(n));
                MinimapData.save();
            }
            folderBox.setValue("");
        }).bounds(w / 2 + 168, 28, 70, 20).build());

        List<Waypoint> list = filtered();
        int y0 = 58;
        int n = Math.min(ROWS, Math.max(0, list.size() - scroll));
        for (int i = 0; i < n; i++) {
            final int fi = scroll + i;
            Waypoint wp = list.get(fi);
            int y = y0 + i * ROW_H;
            int bx = w - 150;

            addRenderableWidget(Button.builder(Component.literal("X"), b -> pendingDelete = fi)
                    .bounds(bx, y, 20, 20).build());
            addRenderableWidget(Button.builder(Component.literal(" "), b -> {
                wp.hidden = !wp.hidden;
                MinimapData.save();
                rebuild();
            }).bounds(bx + 24, y, 20, 20).build());
            addRenderableWidget(Button.builder(Component.literal("E"), b ->
                            this.minecraft.setScreen(new WaypointEditScreen(wp)))
                    .bounds(bx + 48, y, 20, 20).build());
        }

        if (pendingDelete >= 0 && pendingDelete < MinimapData.get().waypoints.size()) {
            addRenderableWidget(Button.builder(Component.literal("Удалить метку? Да"), b -> {
                MinimapData.get().waypoints.remove(pendingDelete);
                pendingDelete = -1;
                MinimapData.save();
                rebuild();
            }).bounds(w / 2 - 90, this.height / 2 - 10, 90, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Нет"), b -> {
                pendingDelete = -1;
                rebuild();
            }).bounds(w / 2 + 4, this.height / 2 - 10, 86, 20).build());
        }

        if (list.size() > ROWS) {
            addRenderableWidget(Button.builder(Component.literal("^"), b -> {
                if (scroll > 0) { scroll--; rebuild(); }
            }).bounds(w / 2 - 60, y0 + ROWS * ROW_H + 4, 20, 20).build());
            addRenderableWidget(Button.builder(Component.literal("v"), b -> {
                if (scroll + ROWS < list.size()) { scroll++; rebuild(); }
            }).bounds(w / 2 + 40, y0 + ROWS * ROW_H + 4, 20, 20).build());
        }

        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose())
                .bounds(w / 2 - 60, this.height - 28, 120, 20).build());
    }

    private List<Waypoint> filtered() {
        List<Waypoint> out = new ArrayList<>();
        for (Waypoint wp : MinimapData.get().waypoints) {
            if (currentFolder.equals("all") || (wp.folders != null && wp.folders.contains(currentFolder))) {
                out.add(wp);
            }
        }
        return out;
    }

    private String folderLabel() {
        return currentFolder.equals("all") ? "Папка: Все" : "Папка: " + currentFolder;
    }

    private boolean folderVisible() {
        Folder f = MinimapData.findFolder(currentFolder);
        return f == null || f.visible;
    }

    private void cycleFolder() {
        List<String> names = new ArrayList<>();
        names.add("all");
        for (Folder f : MinimapData.get().folders) names.add(f.name);
        int idx = names.indexOf(currentFolder);
        currentFolder = names.get((idx + 1) % names.size());
        scroll = 0;
        rebuild();
    }

    private void rebuild() {
        clearWidgets();
        init();
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double dx, double dy) {
        List<Waypoint> list = filtered();
        if (dy < 0 && scroll + ROWS < list.size()) { scroll++; rebuild(); return true; }
        if (dy > 0 && scroll > 0) { scroll--; rebuild(); return true; }
        return super.mouseScrolled(mx, my, dx, dy);
    }

    @Override
    public void onClose() {
        MinimapData.save();
        this.minecraft.setScreen(null);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g, mouseX, mouseY, partial);
        g.drawCenteredString(this.font, this.title, this.width / 2, 12, 0xFFFFFF);

        List<Waypoint> list = filtered();
        int y0 = 58;
        int n = Math.min(ROWS, Math.max(0, list.size() - scroll));
        for (int i = 0; i < n; i++) {
            Waypoint wp = list.get(scroll + i);
            int y = y0 + i * ROW_H;
            g.fill(16, y - 2, this.width - 16, y + 20, 0x38FFFFFF);

            if (wp.isZone) {
                g.renderOutline(22, y + 3, 36, y + 15, wp.color);
            } else {
                g.fill(26, y + 7, 32, y + 13, wp.color);
            }

            String nm = wp.name;
            if (this.font.width(nm) > 150) {
                nm = this.font.plainSubstrByWidth(nm, 140) + "..";
            }
            g.drawString(this.font, nm, 42, y + 3, 0xFFFFFF);
            if (wp.hidden) g.drawString(this.font, "скрыта", 42, y + 12, 0xFF909090);

            int cxs = 200;
            g.fill(cxs, y + 3, cxs + 12, y + 15, wp.color);
            g.renderOutline(cxs, y + 3, cxs + 12, y + 15, 0xFF000000);

            String co = wp.isZone
                    ? wp.minX() + "," + wp.minZ() + " - " + wp.maxX() + "," + wp.maxZ()
                    : wp.x + ", " + wp.y + ", " + wp.z;
            g.drawString(this.font, co, cxs + 18, y + 5, 0xFFAAAAAA);
        }

        if (pendingDelete >= 0) {
            g.fill(0, 0, this.width, this.height, 0x90000000);
        }
        super.render(g, mouseX, mouseY, partial);
    }
}
