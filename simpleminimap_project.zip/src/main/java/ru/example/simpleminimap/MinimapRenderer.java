package ru.example.simpleminimap;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.GrassBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;

public class MinimapRenderer {

    private static class ChunkData {
        final int[][] color = new int[16][16];
        final int[][] height = new int[16][16];
        long lastScan;
    }

    private static final Map<Long, ChunkData> cache = new HashMap<>();
    private static final Queue<Long> pending = new ArrayDeque<>();
    private static DynamicTexture texture;
    private static NativeImage img;
    private static ResourceLocation texId;
    private static int imgRadius = -1;
    private static long lastRepaint = 0;

    public static int[] plusRect = new int[4];
    public static int[] listRect = new int[4];
    public static int[] eyeRect = new int[4];
    public static boolean mapOnScreen = false;

    public static boolean inRect(int[] r, double gx, double gy) {
        return gx >= r[0] && gx <= r[2] && gy >= r[1] && gy <= r[3];
    }

    private static long pack(int x, int z) {
        return ((long) z << 32) ^ (x & 0xFFFFFFFFL);
    }

    private static int unpackX(long key) { return (int) key; }
    private static int unpackZ(long key) { return (int) (key >> 32); }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        var cp = mc.player.chunkPosition();
        int cr = (Settings.radius + 15) / 16 + 1;

        for (int dx = -cr; dx <= cr; dx++) {
            for (int dz = -cr; dz <= cr; dz++) {
                long k = pack(cp.x + dx, cp.z + dz);
                if (!cache.containsKey(k) && !pending.contains(k)) pending.add(k);
            }
        }

        int budget = Settings.scanPerTick;
        while (budget > 0 && !pending.isEmpty()) {
            long k = pending.poll();
            LevelChunk ch = mc.level.getChunkSource().getChunkNow(unpackX(k), unpackZ(k));
            if (ch == null) { pending.add(k); break; }
            scanChunk(mc.level, unpackX(k), unpackZ(k));
            budget -= 256;
        }

        long now = System.currentTimeMillis();
        int rescans = 2;
        for (Map.Entry<Long, ChunkData> en : cache.entrySet()) {
            if (rescans <= 0) break;
            if (now - en.getValue().lastScan > Settings.rescanMs) {
                int cx = unpackX(en.getKey()), cz = unpackZ(en.getKey());
                if (mc.level.getChunkSource().getChunkNow(cx, cz) != null) {
                    scanChunk(mc.level, cx, cz);
                    rescans--;
                }
            }
        }

        if (cache.size() > 1200) {
            cache.entrySet().removeIf(e2 -> Math.abs(unpackX(e2.getKey()) - cp.x) > cr + 4
                    || Math.abs(unpackZ(e2.getKey()) - cp.z) > cr + 4);
        }
    }

    private static void scanChunk(Level level, int cx, int cz) {
        LevelChunk ch = level.getChunkSource().getChunkNow(cx, cz);
        if (ch == null) return;
        ChunkData d = new ChunkData();
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int wx = (cx << 4) | x, wz = (cz << 4) | z;
                int top = Math.max(1, ch.getHeight(Heightmap.Types.WORLD_SURFACE, x, z));
                BlockPos pos = new BlockPos(wx, top, wz);
                BlockState s = ch.getBlockState(pos);
                int c = s.getMapColor(level, pos).col;
                var biome = level.getBiome(pos).value();
                if (s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.SHORT_GRASS) || s.is(Blocks.TALL_GRASS)) {
                    c = mix(c, biome.getGrassColor(wx, wz) | 0xFF000000, 0.6f);
                } else if (s.is(BlockTags.LEAVES)) {
                    c = mix(c, biome.getFoliageColor() | 0xFF000000, 0.6f);
                } else if (s.is(Blocks.WATER)) {
                    c = mix(c, biome.getWaterColor() | 0xFF000000, 0.5f);
                }
                d.color[x][z] = c;
                d.height[x][z] = top;
            }
        }
        d.lastScan = System.currentTimeMillis();
        cache.put(pack(cx, cz), d);
    }

    private static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r = (int) (ar + (br - ar) * t);
        int g = (int) (ag + (bg - ag) * t);
        int bl = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int heightAt(int wx, int wz) {
        ChunkData d = cache.get(pack(Math.floorDiv(wx, 16), Math.floorDiv(wz, 16)));
        if (d == null) return -1;
        return d.height[Math.floorMod(wx, 16)][Math.floorMod(wz, 16)];
    }

    private static int applyShade(int argb, float f) {
        f = Math.max(0.55f, Math.min(1.45f, f));
        int r = Math.min(255, (int) (((argb >> 16) & 0xFF) * f));
        int g = Math.min(255, (int) (((argb >> 8) & 0xFF) * f));
        int b = Math.min(255, (int) ((argb & 0xFF) * f));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int toAbgr(int argb) {
        int a = (argb >>> 24) & 0xFF, r = (argb >> 16) & 0xFF, g = (argb >> 8) & 0xFF, b = argb & 0xFF;
        return (a << 24) | (b << 16) | (g << 8) | r;
    }

    private static void ensureTexture(Minecraft mc) {
        if (texture != null && imgRadius == Settings.radius) return;
        if (texId != null) mc.getTextureManager().release(texId);
        imgRadius = Settings.radius;
        int side = imgRadius * 2;
        img = new NativeImage(side, side, true);
        texture = new DynamicTexture(img);
        texId = mc.getTextureManager().register(
                ResourceLocation.fromNamespaceAndPath(SimpleMinimap.MODID, "minimap"), texture);
    }

    private static void repaint(Minecraft mc) {
        long now = System.currentTimeMillis();
        if (now - lastRepaint < Settings.repaintMs) return;
        lastRepaint = now;
        ensureTexture(mc);
        if (mc.player == null || mc.level == null) return;

        int r = Settings.radius;
        int px = mc.player.getBlockX(), pz = mc.player.getBlockZ();

        for (int dx = -r; dx < r; dx++) {
            for (int dz = -r; dz < r; dz++) {
                int wx = px + dx, wz = pz + dz;
                ChunkData d = cache.get(pack(Math.floorDiv(wx, 16), Math.floorDiv(wz, 16)));
                int argb = 0;
                if (d != null) {
                    int c = d.color[Math.floorMod(wx, 16)][Math.floorMod(wz, 16)];
                    int h1 = d.height[Math.floorMod(wx, 16)][Math.floorMod(wz, 16)];
                    int h2 = heightAt(wx + 1, wz + 1);
                    float shade = h2 < 0 ? 1f : 1 + (h1 - h2) * 0.06f;
                    argb = applyShade(c, shade);
                }
                img.setPixel(dx + r, dz + r, toAbgr(argb));
            }
        }
        texture.upload();
    }

    public static void render(GuiGraphics g, Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        repaint(mc);

        int r = Settings.radius;
        int side = r * 2;
        int size = (int) (side * Settings.scale);
        int x0 = g.guiWidth() - size - 6;
        int y0 = 6;
        float s = Settings.scale;
        int px = mc.player.getBlockX(), pz = mc.player.getBlockZ();

        mapOnScreen = true;
        plusRect = new int[]{x0 + size - 16, y0 - 18, x0 + size - 2, y0 - 4};
        listRect = new int[]{x0 + size - 36, y0 - 18, x0 + size - 22, y0 - 4};
        eyeRect = new int[]{x0 + size - 56, y0 - 18, x0 + size - 42, y0 - 4};

        g.fill(x0 - 2, y0 - 2, x0 + size + 2, y0 + size + 2, 0xC0000000);
        if (texId != null) g.blit(texId, x0, y0, size, size, 0, 0, side, side, side, side);

        // сетка чанков
        int gxStart = Math.floorDiv(px - r, 16) * 16;
        for (int gx = gxStart; gx <= px + r; gx += 16) {
            int sx = x0 + (int) ((gx - (px - r)) * s);
            if (sx >= x0 && sx <= x0 + size) g.fill(sx, y0, sx + 1, y0 + size, 0x30FFFFFF);
        }
        int gzStart = Math.floorDiv(pz - r, 16) * 16;
        for (int gz = gzStart; gz <= pz + r; gz += 16) {
            int sy = y0 + (int) ((gz - (pz - r)) * s);
            if (sy >= y0 && sy <= y0 + size) g.fill(x0, sy, x0 + size, sy + 1, 0x30FFFFFF);
        }

        // сущности
        for (Entity e : mc.level.entitiesForRendering()) {
            double dx = e.getX() - (px + 0.5), dz = e.getZ() - (pz + 0.5);
            if (Math.abs(dx) > r || Math.abs(dz) > r) continue;
            boolean edge = Math.abs(dx) > r - 2 || Math.abs(dz) > r - 2;
            int sx = x0 + (int) Math.max(1, Math.min(size - 1, (dx + r) * s));
            int sy = y0 + (int) Math.max(1, Math.min(size - 1, (dz + r) * s));
            int c = colorOf(e);
            if (edge) c = (0x78 << 24) | (c & 0xFFFFFF);
            g.fill(sx - 1, sy - 1, sx + 1, sy + 1, c);
        }

        // зоны
        for (Waypoint w : MinimapData.get().waypoints) {
            if (!w.isZone) continue;
            int vis = MinimapData.mapVisibility(w);
            if (vis == 0) continue;
            int ax = Math.min(w.x, w.x2), bx = Math.max(w.x, w.x2);
            int az = Math.min(w.z, w.z2), bz = Math.max(w.z, w.z2);
            int sx1 = Math.max(x0, x0 + (int) ((ax - (px - r)) * s));
            int sx2 = Math.min(x0 + size, x0 + (int) ((bx + 1 - (px - r)) * s));
            int sy1 = Math.max(y0, y0 + (int) ((az - (pz - r)) * s));
            int sy2 = Math.min(y0 + size, y0 + (int) ((bz + 1 - (pz - r)) * s));
            if (sx2 <= sx1 || sy2 <= sy1) continue;
            int alpha = vis == 2 ? 0x1A : 0x66;
            g.fill(sx1, sy1, sx2, sy2, (alpha << 24) | (w.mapColor & 0xFFFFFF));
            g.renderOutline(sx1, sy1, sx2, sy2, (alpha << 24) | (w.mapColor & 0xFFFFFF));
        }

        // метки-точки
        for (Waypoint w : MinimapData.get().waypoints) {
            if (w.isZone) continue;
            int vis = MinimapData.mapVisibility(w);
            if (vis == 0) continue;
            int dx = w.x - px, dz = w.z - pz;
            boolean edge = Math.abs(dx) >= r - 1 || Math.abs(dz) >= r - 1;
            int cx = x0 + (int) Math.max(0, Math.min(size - 3, (dx + r) * s));
            int cy = y0 + (int) Math.max(0, Math.min(size - 3, (dz + r) * s));
            int alpha = vis == 2 ? 0x40 : 0xFF;
            if (edge) alpha = (int) (alpha * 0.4);
            g.fill(cx, cy, cx + 3, cy + 3, (alpha << 24) | (w.color & 0xFFFFFF));
            g.renderOutline(cx - 1, cy - 1, cx + 4, cy + 4, (alpha << 24) | 0x000000);
            if (!edge && !w.name.isEmpty()) {
                String ch = w.name.substring(0, 1).toUpperCase();
                g.drawString(mc.font, ch, cx, cy - 8, (alpha << 24) | 0xFFFFFF);
            }
        }

        // стрелка игрока
        var pose = g.pose();
        pose.pushPose();
        float cx = x0 + size / 2f, cy = y0 + size / 2f;
        pose.translate(cx, cy, 0);
        pose.mulPose(Axis.ZP.rotationDegrees(180 - mc.player.getYRot()));
        g.fill(-3, -8, 3, 5, 0xFF000000);
        g.fill(-1, -7, 1, 3, 0xFFFFFFFF);
        g.fill(-2, -7, 2, -5, 0xFFFFFFFF);
        g.fill(-2, 2, 2, 4, 0xFF404040);
        pose.popPose();

        // подписи под картой
        String info = "X " + px + "  Y " + mc.player.getBlockY() + "  Z " + pz + "   " + biomeName(mc);
        g.drawCenteredString(mc.font, info, x0 + size / 2, y0 + size + 5, 0xFFFFFF);

        // кнопки: [глаз] [список] [плюс]
        drawButton(g, eyeRect, null);
        drawButton(g, listRect, null);
        drawButton(g, plusRect, "+");

        // глаз: открытый (призраки видны) / перечёркнутый (скрыты)
        int ex0 = eyeRect[0] + 3, ey0 = eyeRect[1] + 4, ex1 = eyeRect[2] - 3, ey1 = eyeRect[3] - 4;
        g.renderOutline(ex0, ey0, ex1, ey1, 0xFFFFFFFF);
        g.fill((ex0 + ex1) / 2 - 1, (ey0 + ey1) / 2 - 1, (ex0 + ex1) / 2 + 1, (ey0 + ey1) / 2 + 1, 0xFFFFFFFF);
        if (MinimapData.get().hideGhosts) {
            for (int i = 0; i < ex1 - ex0; i++) {
                g.fill(ex0 + i, ey0 + i, ex0 + i + 1, ey0 + i + 1, 0xFFFF5555);
            }
        }
        // список: три линии
        for (int i = 0; i < 3; i++) {
            int ly = listRect[1] + 4 + i * 3;
            g.fill(listRect[0] + 3, ly, listRect[2] - 3, ly + 1, 0xFFFFFFFF);
        }
    }

    private static void drawButton(GuiGraphics g, int[] rect, String label) {
        g.fill(rect[0], rect[1], rect[2], rect[3], 0x90000000);
        g.renderOutline(rect[0], rect[1], rect[2], rect[3], 0xFFFFFFFF);
        if (label != null) {
            g.drawString(Minecraft.getInstance().font, label, rect[0] + 5, rect[1] + 3, 0xFFFFFF);
        }
    }

    private static int colorOf(Entity e) {
        if (e instanceof Player) return 0xFF55FFFF;
        if (e instanceof Enemy) return 0xFFFF5555;
        if (e instanceof Animal) return 0xFFFFAA00;
        if (e instanceof net.minecraft.world.entity.Mob) return 0xFFAAAAAA;
        return 0xFF888888;
    }

    private static String biomeName(Minecraft mc) {
        try {
            var holder = mc.level.getBiome(mc.player.blockPosition());
            var key = mc.level.registryAccess().registryOrThrow(Registries.BIOME).getKey(holder.value());
            if (key != null) {
                String s = key.getPath().replace('_', ' ');
                return s.substring(0, 1).toUpperCase() + s.substring(1);
            }
        } catch (Exception ignored) {}
        return "";
    }
}
