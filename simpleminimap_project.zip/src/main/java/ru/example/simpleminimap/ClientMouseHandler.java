package ru.example.simpleminimap;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SimpleMinimap.MODID, value = Dist.CLIENT)
public class ClientMouseHandler {

    @SubscribeEvent
    public static void onMouse(InputEvent.MouseButtonPressed e) {
        Minecraft mc = Minecraft.getInstance();
        if (!HudOverlay.visible || !MinimapRenderer.mapOnScreen) return;
        if (mc.player == null || mc.screen != null) return;

        double gs = mc.getWindow().getGuiScale();
        double gx = e.getX() * gs, gy = e.getY() * gs;

        if (MinimapRenderer.inRect(MinimapRenderer.plusRect, gx, gy)) {
            Waypoint wpt = new Waypoint();
            wpt.x = mc.player.getBlockX();
            wpt.y = mc.player.getBlockY();
            wpt.z = mc.player.getBlockZ();
            wpt.name = "Точка " + (MinimapData.get().waypoints.size() + 1);
            wpt.color = Settings.PALETTE[MinimapData.get().waypoints.size() % Settings.PALETTE.length];
            wpt.folders.add("all");
            mc.setScreen(new WaypointEditScreen(wpt));
        } else if (MinimapRenderer.inRect(MinimapRenderer.listRect, gx, gy)) {
            mc.setScreen(new WaypointsScreen());
        } else if (MinimapRenderer.inRect(MinimapRenderer.eyeRect, gx, gy)) {
            MinimapData.get().hideGhosts = !MinimapData.get().hideGhosts;
            MinimapData.save();
        }
    }
}
