package ru.example.simpleminimap;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SimpleMinimap.MODID, value = Dist.CLIENT)
public class ClientTickHandler {

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            ZoneCreation.reset();
            return;
        }
        if (mc.screen != null) return;

        long w = mc.getWindow().getWindow();

        // 1. карта вкл/выкл
        if (Settings.TOGGLE_MAP.keys.length > 0) {
            if (edge(Settings.TOGGLE_MAP.matches(w), 0)) HudOverlay.visible = !HudOverlay.visible;
        } else {
            while (Keybinds.TOGGLE_MAP.consumeClick()) HudOverlay.visible = !HudOverlay.visible;
        }

        // 2. настройки
        if (Settings.OPEN_SETTINGS.keys.length > 0) {
            if (edge(Settings.OPEN_SETTINGS.matches(w), 1)) mc.setScreen(new SettingsScreen(null));
        } else {
            while (Keybinds.OPEN_SETTINGS.consumeClick()) mc.setScreen(new SettingsScreen(null));
        }

        // 3. быстрая метка
        if (Settings.QUICK_WAYPOINT.keys.length > 0) {
            if (edge(Settings.QUICK_WAYPOINT.matches(w), 2)) quickWaypoint(mc);
        } else {
            while (Keybinds.QUICK_WAYPOINT.consumeClick()) quickWaypoint(mc);
        }

        // 4. зона: старт
        boolean zoneStart = Settings.ZONE_START.keys.length > 0
                ? edge(Settings.ZONE_START.matches(w), 3)
                : Keybinds.ZONE_START.consumeClick();
        if (zoneStart && Screen.hasShiftDown() && ZoneCreation.state == ZoneCreation.State.NONE) {
            ZoneCreation.start();
        }

        // 5-6. точки зоны
        boolean p1 = Settings.ZONE_P1.keys.length > 0
                ? edge(Settings.ZONE_P1.matches(w), 4)
                : Keybinds.ZONE_P1.consumeClick();
        if (p1 && ZoneCreation.state == ZoneCreation.State.P1) ZoneCreation.onP1();

        boolean p2 = Settings.ZONE_P2.keys.length > 0
                ? edge(Settings.ZONE_P2.matches(w), 5)
                : Keybinds.ZONE_P2.consumeClick();
        if (p2 && ZoneCreation.state == ZoneCreation.State.P2) ZoneCreation.onP2();

        MinimapRenderer.tick();
    }

    private static final boolean[] prev = new boolean[6];

    private static boolean edge(boolean now, int idx) {
        boolean was = prev[idx];
        prev[idx] = now;
        return now && !was;
    }

    static void quickWaypoint(Minecraft mc) {
        Waypoint wpt = new Waypoint();
        wpt.x = mc.player.getBlockX();
        wpt.y = mc.player.getBlockY();
        wpt.z = mc.player.getBlockZ();
        wpt.name = "Точка " + (MinimapData.get().waypoints.size() + 1);
        wpt.color = Settings.PALETTE[MinimapData.get().waypoints.size() % Settings.PALETTE.length];
        wpt.folders.add("all");
        MinimapData.get().waypoints.add(wpt);
        MinimapData.save();
        mc.player.displayClientMessage(Component.literal("Метка создана: " + wpt.name), true);
    }
}
