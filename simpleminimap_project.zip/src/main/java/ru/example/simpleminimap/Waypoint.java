package ru.example.simpleminimap;

import java.util.ArrayList;
import java.util.List;

public class Waypoint {
    public String name = "Точка";
    public int x, y, z;
    public int color = 0xFFFF5555;
    public boolean hidden = false;
    public boolean isZone = false;

    public int x2, z2;
    public int borderColor = 0xFFFF5555;
    public int fillColor = 0x66FF5555;
    public int mapColor = 0xFFFF5555;
    public int labelX = 16, labelZ = 16;

    public List<String> folders = new ArrayList<>();

    public int minX() { return isZone ? Math.min(x, x2) : x; }
    public int maxX() { return isZone ? Math.max(x, x2) : x; }
    public int minZ() { return isZone ? Math.min(z, z2) : z; }
    public int maxZ() { return isZone ? Math.max(z, z2) : z; }
}
