package ru.example.simpleminimap;

import com.mojang.blaze3d.platform.InputConstants;

public class KeyCombo {
    public int[] keys = new int[0];
    public String label = "-";

    public boolean matches(long window) {
        if (keys == null || keys.length == 0) return false;
        for (int k : keys) {
            if (!InputConstants.isKeyDown(window, k)) return false;
        }
        return true;
    }

    public void set(int[] k, String l) {
        keys = (k == null) ? new int[0] : k;
        label = (l == null || l.isEmpty()) ? "-" : l;
    }

    public void setCsv(String csv) {
        try {
            if (csv == null || csv.isBlank()) { keys = new int[0]; return; }
            String[] parts = csv.split(",");
            keys = new int[parts.length];
            for (int i = 0; i < parts.length; i++) keys[i] = Integer.parseInt(parts[i].trim());
        } catch (Exception e) {
            keys = new int[0];
        }
    }

    public String csv() {
        if (keys == null || keys.length == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < keys.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(keys[i]);
        }
        return sb.toString();
    }

    public static String keyName(int code) {
        if (code == 340 || code == 344) return "Shift";
        if (code == 341 || code == 345) return "Ctrl";
        if (code == 342 || code == 346) return "Alt";
        if (code == 263) return "Left";
        if (code == 262) return "Right";
        if (code == 264) return "Up";
        if (code == 265) return "Down";
        if (code == 256) return "Esc";
        if (code == 258) return "Tab";
        if (code == 259) return "Backspace";
        if (code >= 65 && code <= 90) return String.valueOf((char) code);
        if (code >= 48 && code <= 57) return String.valueOf((char) code);
        if (code == 32) return "Space";
        String g = org.lwjgl.glfw.GLFW.glfwGetKeyName(code, 0);
        if (g != null && !g.isEmpty()) return g.toUpperCase();
        return "Key" + code;
    }
}
