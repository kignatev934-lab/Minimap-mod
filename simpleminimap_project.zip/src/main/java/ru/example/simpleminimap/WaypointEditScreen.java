package ru.example.simpleminimap;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class WaypointEditScreen extends Screen {
    private final Waypoint w;
    private EditBox name, fx, fy, fz, labX, labZ;
    private boolean isZone;
    private int colorIdx, borderIdx, fillIdx, mapIdx;
    private final Map<String, Boolean> checks = new HashMap<>();
    private boolean confirmDelete = false;
    private Button deleteBtn;

    public WaypointEditScreen(Waypoint w) {
        super(Component.literal("Редактор метки"));
        this.w = w;
    }

    @Override
    protected void init() {
        isZone = w.isZone;
        colorIdx = idxOfColor(w.color);
        borderIdx = idxOfColor(w.borderColor);
        fillIdx = idxOfColor(w.fillColor);
        mapIdx = idxOfColor(w.mapColor);

        int wd = this.width;
        name = field(wd / 2 - 100, 32, 200, w.name);

        fx = field(wd / 2 - 100, 58, 60, String.valueOf(w.x));
        fy = field(wd / 2 - 30, 58, 60, String.valueOf(w.y));
        fz = field(wd / 2 + 40, 58, 60, String.valueOf(w.z));

        int y = 84;
        addRenderableWidget(Button.builder(Component.literal(typeLabel()), b -> {
            isZone = !isZone;
            b.setMessage(Component.literal(typeLabel()));
        }).bounds(wd / 2 - 100, y, 100, 20).build());
        colorBtn("Цвет метки", wd / 2 + 10, y, () -> colorIdx, i -> colorIdx = i);
        y += 26;

        // зона-специфика: цвета и размер подписи
        int zoneY = y;
        colorBtn("Обводка", wd / 2 - 100, zoneY, () -> borderIdx, i -> borderIdx = i);
        colorBtn("Заливка", wd / 2 + 10, zoneY, () -> fillIdx, i -> fillIdx = i);
        colorBtn("На карте", wd / 2 - 100, zoneY + 24, () -> mapIdx, i -> mapIdx = i);
        labX = field(wd / 2 + 10, zoneY + 24, 40, String.valueOf(w.labelX));
        labZ = field(wd / 2 + 60, zoneY + 24, 40, String.valueOf(w.labelZ));

        int fy2 = zoneY + 54;
        int fx2 = wd / 2 - 100;
        for (Folder f : MinimapData.get().folders) {
            checks.putIfAbsent(f.name, w.folders != null && w.folders.contains(f.name));
            final String fname = f.name;
            Button cb = Button.builder(Component.literal((checks.get(f.name) ? "[x] " : "[ ] ") + f.name), b -> {
                boolean nv = !checks.get(fname);
                checks.put(fname, nv);
                b.setMessage(Component.literal((nv ? "[x] " : "[ ] ") + fname));
            }).bounds(fx2, fy2, 90, 18).build();
            addRenderableWidget(cb);
            fx2 += 95;
            if (fx2 > wd - 100) { fx2 = wd / 2 - 100; fy2 += 20; }
        }

        int by = Math.max(fy2 + 8, zoneY + 84);
        deleteBtn = Button.builder(Component.literal("Удалить"), b -> {
            if (confirmDelete) {
                MinimapData.get().waypoints.remove(w);
                MinimapData.save();
                onClose();
            } else {
                confirmDelete = true;
                b.setMessage(Component.literal("Точно удалить?"));
            }
        }).bounds(wd / 2 + 10, by, 90, 20).build();
        addRenderableWidget(deleteBtn);
        addRenderableWidget(Button.builder(Component.literal("Сохранить"), b -> save())
                .bounds(wd / 2 - 100, by, 90, 20).build());
    }

    private EditBox field(int x, int y, int w2, String val) {
        EditBox e = new EditBox(this.font, x, y, w2, 18, Component.literal(""));
        e.setMaxLength(48);
        e.setValue(val);
        addRenderableWidget(e);
        return e;
    }

    private void colorBtn(String label, int x, int y, java.util.function.Supplier<Integer> get,
                          java.util.function.Consumer<Integer> set) {
        addRenderableWidget(Button.builder(Component.literal(label), b -> {
            set.accept((get.get() + 1) % Settings.PALETTE.length);
        }).bounds(x, y, 90, 20).build());
    }

    private String typeLabel() {
        return isZone ? "Тип: зона" : "Тип: точка";
    }

    private int idxOfColor(int c) {
        for (int i = 0; i < Settings.PALETTE.length; i++) {
            if ((Settings.PALETTE[i] & 0xFFFFFF) == (c & 0xFFFFFF)) return i;
        }
        return 0;
    }

    private void save() {
        w.name = name.getValue().isEmpty() ? w.name : name.getValue();
        try { w.x = Integer.parseInt(fx.getValue().trim()); } catch (Exception ignored) {}
        try { w.y = Integer.parseInt(fy.getValue().trim()); } catch (Exception ignored) {}
        try { w.z = Integer.parseInt(fz.getValue().trim()); } catch (Exception ignored) {}
        w.isZone = isZone;
        w.color = Settings.PALETTE[colorIdx % Settings.PALETTE.length];
        w.borderColor = Settings.PALETTE[borderIdx % Settings.PALETTE.length];
        w.mapColor = Settings.PALETTE[mapIdx % Settings.PALETTE.length];
        w.fillColor = (0x66 << 24) | (Settings.PALETTE[fillIdx % Settings.PALETTE.length] & 0xFFFFFF);
        if (isZone) {
            try { w.labelX = Math.max(2, Integer.parseInt(labX.getValue().trim())); } catch (Exception ignored) {}
            try { w.labelZ = Math.max(2, Integer.parseInt(labZ.getValue().trim())); } catch (Exception ignored) {}
        }
        w.folders = new ArrayList<>();
        for (Map.Entry<String, Boolean> en : checks.entrySet()) {
            if (en.getValue()) w.folders.add(en.getKey());
        }
        if (!MinimapData.get().waypoints.contains(w)) {
            MinimapData.get().waypoints.add(w);
        }
        MinimapData.save();
        onClose();
    }

    @Override
    public void onClose() {
        MinimapData.save();
        this.minecraft.setScreen(null);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g, mouseX, mouseY, partial);
        g.drawCenteredString(this.font, this.title, this.width / 2, 14, 0xFFFFFF);

        int wd = this.width;
        g.drawString(this.font, "Название", wd / 2 - 100, 22, 0xFFAAAAAA);
        g.drawString(this.font, "X", wd / 2 - 100, 50, 0xFFAAAAAA);
        g.drawString(this.font, "Y", wd / 2 - 30, 50, 0xFFAAAAAA);
        g.drawString(this.font, "Z", wd / 2 + 40, 50, 0xFFAAAAAA);

        // квадратики цветов рядом с кнопками
        int y = 84;
        g.fill(wd / 2 + 102, y + 3, wd / 2 + 114, y + 15, Settings.PALETTE[colorIdx % Settings.PALETTE.length]);
        int zy = y + 26;
        g.fill(wd / 2 - 8, zy + 3, wd / 2 + 4, zy + 15, Settings.PALETTE[borderIdx % Settings.PALETTE.length]);
        g.fill(wd / 2 + 102, zy + 3, wd / 2 + 114, zy + 15, Settings.PALETTE[fillIdx % Settings.PALETTE.length]);
        g.fill(wd / 2 - 8, zy + 27, wd / 2 + 4, zy + 39, Settings.PALETTE[mapIdx % Settings.PALETTE.length]);
        g.drawString(this.font, "X", wd / 2 + 2, zy + 26, 0xFFAAAAAA);
        g.drawString(this.font, "Z", wd / 2 + 52, zy + 26, 0xFFAAAAAA);

        super.render(g, mouseX, mouseY, partial);
    }
}
