package ru.example.simpleminimap;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

@Mod.EventBusSubscriber(modid = SimpleMinimap.MODID, value = Dist.CLIENT)
public class WorldRender {

    @SubscribeEvent
    public static void onStage(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        Vec3 cam = e.getCamera().getPosition();
        PoseStack ms = e.getPoseStack();
        ms.pushPose();
        ms.translate(-cam.x, -cam.y, -cam.z);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        boolean drewLabel = false;
        for (Waypoint w : MinimapData.get().waypoints) {
            if (!w.isZone || !MinimapData.worldVisible(w)) continue;
            float x1 = Math.min(w.x, w.x2);
            float x2 = Math.max(w.x, w.x2) + 1;
            float z1 = Math.min(w.z, w.z2);
            float z2 = Math.max(w.z, w.z2) + 1;
            int gxi = Math.floorDiv((int) ((x1 + x2) / 2), 1);
            int gy = mc.level.getHeight(Heightmap.Types.WORLD_SURFACE,
                    (int) ((x1 + x2) / 2), (int) ((z1 + z2) / 2));
            float y0 = gy;

            Matrix4f m = ms.last().pose();

            // заливка — горизонтальная плоскость на уровне земли
            int fr = (w.fillColor >> 16) & 0xFF, fg = (w.fillColor >> 8) & 0xFF,
                    fb = w.fillColor & 0xFF, fa = (w.fillColor >>> 24) & 0xFF;
            BufferBuilder buf = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS,
                    DefaultVertexFormat.POSITION_COLOR);
            buf.addVertex(m, x1, y0, z1).setColor(fr, fg, fb, fa);
            buf.addVertex(m, x1, y0, z2).setColor(fr, fg, fb, fa);
            buf.addVertex(m, x2, y0, z2).setColor(fr, fg, fb, fa);
            buf.addVertex(m, x2, y0, z1).setColor(fr, fg, fb, fa);
            BufferUploader.drawWithShader(buf.buildOrThrow());

            // рамка — линии по периметру + столбики по углам
            int br = (w.borderColor >> 16) & 0xFF, bg = (w.borderColor >> 8) & 0xFF,
                    bb = w.borderColor & 0xFF, ba = (w.borderColor >>> 24) & 0xFF;
            RenderSystem.lineWidth(2f);
            BufferBuilder lb = Tesselator.getInstance().begin(VertexFormat.Mode.DEBUG_LINES,
                    DefaultVertexFormat.POSITION_COLOR);
            line(lb, m, x1, y0, z1, x2, y0, z1, br, bg, bb, ba);
            line(lb, m, x2, y0, z1, x2, y0, z2, br, bg, bb, ba);
            line(lb, m, x2, y0, z2, x1, y0, z2, br, bg, bb, ba);
            line(lb, m, x1, y0, z2, x1, y0, z1, br, bg, bb, ba);
            line(lb, m, x1, y0, z1, x1, y0 + 3, z1, br, bg, bb, ba);
            line(lb, m, x2, y0, z1, x2, y0 + 3, z1, br, bg, bb, ba);
            line(lb, m, x2, y0, z2, x2, y0 + 3, z2, br, bg, bb, ba);
            line(lb, m, x1, y0, z2, x1, y0 + 3, z2, br, bg, bb, ba);
            BufferUploader.drawWithShader(lb.buildOrThrow());

            if (!drewLabel) drewLabel = true;
            drawLabel(mc, ms, w, (x1 + x2) / 2f, y0 + 0.05f, (z1 + z2) / 2f);
        }

        ms.popPose();
        RenderSystem.disableBlend();
        if (drewLabel) mc.renderBuffers().bufferSource().endBatch();
    }

    private static void line(BufferBuilder b, Matrix4f m,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             int r, int g, int bl, int a) {
        b.addVertex(m, x1, y1, z1).setColor(r, g, bl, a);
        b.addVertex(m, x2, y2, z2).setColor(r, g, bl, a);
    }

    private static void drawLabel(Minecraft mc, PoseStack ms, Waypoint w,
                                  float cx, float cy, float cz) {
        Font font = mc.font;
        float tw = font.width(w.name) * 0.025f;
        float sx = Math.max(0.1f, w.labelX / Math.max(0.5f, tw));
        float sz = Math.max(0.1f, w.labelZ / (9f * 0.025f));
        ms.pushPose();
        ms.translate(cx, cy, cz);
        ms.mulPose(Axis.XP.rotationDegrees(-90));
        ms.scale(sx, sz, 1);
        font.drawInBatch(w.name, -font.width(w.name) / 2f, -4, w.borderColor,
                false, ms.last().pose(), mc.renderBuffers().bufferSource(),
                Font.DisplayMode.NORMAL, 0, 0xF000F0);
        ms.popPose();
    }
}
