package ru.example.simpleminimap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;

public class MinimapData {
    public java.util.List<Waypoint> waypoints = new ArrayList<>();
    public java.util.List<Folder> folders = new ArrayList<>();
    public boolean hideGhosts = false;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static MinimapData instance;

    public static MinimapData get() {
        if (instance == null) {
            instance = load();
            if (findFolder("all") == null) instance.folders.add(new Folder("all"));
        }
        return instance;
    }

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("simpleminimap/data.json");
    }

    private static MinimapData load() {
        try {
            try (InputStreamReader r = new InputStreamReader(new FileInputStream(file().toFile()), StandardCharsets.UTF_8)) {
                MinimapData d = GSON.fromJson(r, MinimapData.class);
                if (d != null) {
                    if (d.waypoints == null) d.waypoints = new ArrayList<>();
                    if (d.folders == null) d.folders = new ArrayList<>();
                    return d;
                }
            }
        } catch (Exception ignored) {}
        return new MinimapData();
    }

    public static void save() {
        try {
            file().getParent().toFile().mkdirs();
            try (OutputStreamWriter wr = new OutputStreamWriter(new FileOutputStream(file().toFile()), StandardCharsets.UTF_8)) {
                GSON.toJson(instance, wr);
            }
        } catch (Exception ignored) {}
    }

    public static Folder findFolder(String name) {
        for (Folder f : get().folders) if (f.name != null && f.name.equals(name)) return f;
        return null;
    }

    public static boolean worldVisible(Waypoint w) {
        if (w.hidden) return false;
        for (String fn : w.folders) {
            Folder f = findFolder(fn);
            if (f != null && !f.visible) return false;
        }
        return true;
    }

    /** 0 — не рисовать, 1 — полностью, 2 — призрак (25% непрозрачности) */
    public static int mapVisibility(Waypoint w) {
        boolean folderHidden = false;
        for (String fn : w.folders) {
            Folder f = findFolder(fn);
            if (f != null && !f.visible) { folderHidden = true; break; }
        }
        if (folderHidden) return 0;
        if (!w.hidden) return 1;
        return get().hideGhosts ? 0 : 2;
    }
}
