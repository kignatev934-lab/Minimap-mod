package ru.example.simpleminimap;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

public class ZoneCreation {
    public enum State { NONE, P1, P2 }

    public static State state = State.NONE;
    public static int x1, z1;
    public static boolean previewActive = false;
    private static int savedSlot = -1;

    public static void start() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        state = State.P1;
        savedSlot = mc.player.getInventory().selected;
        previewActive = false;
        msg(mc, "Зона: нажмите 1 — первая точка");
    }

    public static void onP1() {
        Minecraft mc = Minecraft.getInstance();
        if (state != State.P1 || mc.player == null) return;
        x1 = mc.player.getBlockX();
        z1 = mc.player.getBlockZ();
        restoreSlot(mc);
        state = State.P2;
        previewActive = true;
        msg(mc, "Зона: нажмите 2 — вторая точка");
    }

    public static void onP2() {
        Minecraft mc = Minecraft.getInstance();
        if (state != State.P2 || mc.player == null) return;
        Waypoint zone = new Waypoint();
        zone.isZone = true;
        zone.x = x1;
        zone.z = z1;
        zone.x2 = mc.player.getBlockX();
        zone.z2 = mc.player.getBlockZ();
        zone.name = "Зона " + (MinimapData.get().waypoints.size() + 1);
        int c = Settings.PALETTE[Math.floorMod(Settings.zoneDefaultColor, Settings.PALETTE.length)];
        zone.color = c;
        zone.borderColor = c;
        zone.mapColor = c;
        zone.fillColor = (0x66 << 24) | (c & 0xFFFFFF);
        zone.folders = new ArrayList<>(List.of("all"));

        MinimapData.get().waypoints.add(zone);
        MinimapData.save();
        restoreSlot(mc);
        state = State.NONE;
        previewActive = false;
        mc.setScreen(new WaypointEditScreen(zone));
    }

    public static void reset() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && savedSlot >= 0) restoreSlot(mc);
        state = State.NONE;
        previewActive = false;
    }

    private static void restoreSlot(Minecraft mc) {
        if (savedSlot >= 0) mc.player.getInventory().selected = savedSlot;
        savedSlot = -1;
    }

    private static void msg(Minecraft mc, String s) {
        mc.player.displayClientMessage(Component.literal(s), true);
    }
}
