package ru.example.simpleminimap;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = SimpleMinimap.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class Keybinds {
    public static final KeyMapping TOGGLE_MAP = key("toggle_map", GLFW.GLFW_KEY_M);
    public static final KeyMapping OPEN_SETTINGS = key("open_settings", GLFW.GLFW_KEY_O);
    public static final KeyMapping QUICK_WAYPOINT = key("quick_waypoint", GLFW.GLFW_KEY_B);
    public static final KeyMapping ZONE_START = key("zone_start", GLFW.GLFW_KEY_Z);
    public static final KeyMapping ZONE_P1 = key("zone_point1", GLFW.GLFW_KEY_1);
    public static final KeyMapping ZONE_P2 = key("zone_point2", GLFW.GLFW_KEY_2);

    private static KeyMapping key(String name, int def) {
        return new KeyMapping("key.simpleminimap." + name,
                InputConstants.Type.KEYSYM, def, "key.categories.simpleminimap");
    }

    @SubscribeEvent
    public static void onRegister(RegisterKeyMappingsEvent e) {
        e.register(TOGGLE_MAP);
        e.register(OPEN_SETTINGS);
        e.register(QUICK_WAYPOINT);
        e.register(ZONE_START);
        e.register(ZONE_P1);
        e.register(ZONE_P2);
    }
}
