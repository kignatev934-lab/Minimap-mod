package ru.example.simpleminimap;

public class Folder {
    public String name;
    public boolean visible = true;

    public Folder() {}
    public Folder(String n) { name = n; }
}
