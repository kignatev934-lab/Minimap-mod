package ru.example.simpleminimap;

import net.minecraftforge.fml.loading.FMLPaths;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

public class Settings {
    public static int radius = 64;
    public static float scale = 0.75f;
    public static int repaintMs = 150;
    public static int scanPerTick = 24;
    public static int rescanMs = 5000;
    public static int zoneDefaultColor = 0;

    public static final int[] PALETTE = {
            0xFFFF5555, 0xFF55FF55, 0xFF5555FF, 0xFFFFFF55,
            0xFFFFAA00, 0xFFAA55FF, 0xFF55FFFF, 0xFFFFFFFF
    };

    public static final KeyCombo TOGGLE_MAP = new KeyCombo();
    public static final KeyCombo OPEN_SETTINGS = new KeyCombo();
    public static final KeyCombo QUICK_WAYPOINT = new KeyCombo();
    public static final KeyCombo ZONE_START = new KeyCombo();
    public static final KeyCombo ZONE_P1 = new KeyCombo();
    public static final KeyCombo ZONE_P2 = new KeyCombo();

    private static boolean loaded = false;

    public static void load() {
        if (loaded) return;
        loaded = true;
        TOGGLE_MAP.set(new int[]{87}, "M");
        OPEN_SETTINGS.set(new int[]{79}, "O");
        QUICK_WAYPOINT.set(new int[]{66}, "B");
        ZONE_START.set(new int[]{340, 90}, "Shift+Z");
        ZONE_P1.set(new int[]{49}, "1");
        ZONE_P2.set(new int[]{50}, "2");

        Properties p = new Properties();
        File f = FMLPaths.CONFIGDIR.get().resolve("simpleminimap/settings.properties").toFile();
        if (f.exists()) {
            try (FileInputStream in = new FileInputStream(f)) {
                p.load(in);
                radius = intOf(p.getProperty("radius"), 64);
                scale = floatOf(p.getProperty("scale"), 0.75f);
                repaintMs = intOf(p.getProperty("repaintMs"), 150);
                scanPerTick = intOf(p.getProperty("scanPerTick"), 24);
                rescanMs = intOf(p.getProperty("rescanMs"), 5000);
                zoneDefaultColor = intOf(p.getProperty("zoneColor"), 0);
                setCsv(TOGGLE_MAP, p, "combo.map", "M");
                setCsv(OPEN_SETTINGS, p, "combo.settings", "O");
                setCsv(QUICK_WAYPOINT, p, "combo.waypoint", "B");
                setCsv(ZONE_START, p, "combo.zone", "Shift+Z");
                setCsv(ZONE_P1, p, "combo.zoneP1", "1");
                setCsv(ZONE_P2, p, "combo.zoneP2", "2");
            } catch (Exception ignored) {}
        }
    }

    private static void setCsv(KeyCombo c, Properties p, String key, String defLabel) {
        String csv = p.getProperty(key, "");
        if (csv.isEmpty()) return;
        c.setCsv(csv);
        c.label = p.getProperty(key + ".label", defLabel);
    }

    public static void save() {
        try {
            Properties p = new Properties();
            p.setProperty("radius", String.valueOf(radius));
            p.setProperty("scale", String.valueOf(scale));
            p.setProperty("repaintMs", String.valueOf(repaintMs));
            p.setProperty("scanPerTick", String.valueOf(scanPerTick));
            p.setProperty("rescanMs", String.valueOf(rescanMs));
            p.setProperty("zoneColor", String.valueOf(zoneDefaultColor));
            p.setProperty("combo.map", TOGGLE_MAP.csv());
            p.setProperty("combo.map.label", TOGGLE_MAP.label);
            p.setProperty("combo.settings", OPEN_SETTINGS.csv());
            p.setProperty("combo.settings.label", OPEN_SETTINGS.label);
            p.setProperty("combo.waypoint", QUICK_WAYPOINT.csv());
            p.setProperty("combo.waypoint.label", QUICK_WAYPOINT.label);
            p.setProperty("combo.zone", ZONE_START.csv());
            p.setProperty("combo.zone.label", ZONE_START.label);
            p.setProperty("combo.zoneP1", ZONE_P1.csv());
            p.setProperty("combo.zoneP1.label", ZONE_P1.label);
            p.setProperty("combo.zoneP2", ZONE_P2.csv());
            p.setProperty("combo.zoneP2.label", ZONE_P2.label);
            File f = FMLPaths.CONFIGDIR.get().resolve("simpleminimap/settings.properties").toFile();
            f.getParentFile().mkdirs();
            try (FileOutputStream out = new FileOutputStream(f)) { p.store(out, "Simple Minimap settings"); }
        } catch (Exception ignored) {}
    }

    private static int intOf(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }

    private static float floatOf(String s, float def) {
        try { return Float.parseFloat(s.trim()); } catch (Exception e) { return def; }
    }
}
